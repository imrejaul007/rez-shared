/**
 * DM-HIGH-04 FIX: Canonical NotificationCategory enum
 *
 * Problem: Backend defined 13 notification categories and canonical defined 8,
 * with zero overlap.
 *
 * This is the single source of truth. All notification handling must use these values.
 */
export enum NotificationCategory {
  ORDER = 'order',
  EARNING = 'earning',
  GENERAL = 'general',
  PROMOTIONAL = 'promotional',
  SOCIAL = 'social',
  SECURITY = 'security',
  SYSTEM = 'system',
  REMINDER = 'reminder',
}

export type NotificationType = 'info' | 'success' | 'warning' | 'error' | 'promotional';
export type NotificationPriority = 'low' | 'medium' | 'high' | 'urgent';
