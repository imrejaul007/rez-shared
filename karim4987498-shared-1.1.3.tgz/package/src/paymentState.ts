/**
 * DM-HIGH-02 FIX: Unified PaymentState enum
 *
 * Two FSM domains existed independently:
 *   1. PaymentStatus (standalone Payment model): financial lifecycle
 *   2. OrderPaymentStatus (Order.payment subdoc): consumer-facing state
 *
 * This unified enum merges both domains for canonical use across services.
 * Use PaymentState everywhere; PaymentStatus and OrderPaymentStatus remain
 * in paymentStatuses.ts for backward compat.
 */
export enum PaymentState {
  PENDING = 'pending',
  AUTHORIZED = 'authorized',
  CAPTURED = 'captured',
  PROCESSING = 'processing',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled',
  EXPIRED = 'expired',
  REFUND_IN_PROGRESS = 'refund_in_progress',
  REFUNDED = 'refunded',
  PARTIALLY_REFUNDED = 'partially_refunded',
}

export const TERMINAL_PAYMENT_STATES: PaymentState[] = [
  PaymentState.COMPLETED,
  PaymentState.CANCELLED,
  PaymentState.EXPIRED,
  PaymentState.REFUNDED,
];
