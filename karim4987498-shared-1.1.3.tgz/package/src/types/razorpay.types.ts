/**
 * Canonical Razorpay payment response types — DM-CRIT-03 fix.
 *
 * Previously each file defined its own interface for Razorpay responses,
 * causing type drift when the SDK changed field names. This is the single
 * source of truth. All Razorpay response handling must import from here.
 *
 * Source: razorpay SDK (https://razorpay.com/docs/payments/payments-api/)
 */

/**
 * Canonical Razorpay payment success/callback response.
 * Fields use snake_case to match Razorpay's actual API response.
 */
export interface RazorpayPaymentResponse {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}

/**
 * Canonical Razorpay order creation response (returned by backend when
 * creating a Razorpay order for the frontend SDK).
 */
export interface RazorpayOrderResponse {
  razorpayOrderId: string;
  amount: number; // in paise
  currency: string;
  keyId: string;
  orderNumber: string;
}

/**
 * Raw Razorpay SDK callback data (passed to the Razorpay popup handler).
 * Use RazorpayPaymentResponse after extraction/verification.
 */
export interface RazorpayCallbackData {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
  /** Amount in paise (sent by backend, echoed by Razorpay) */
  amount?: number;
  /** 'captured' | 'failed' | 'refunded' */
  status?: 'captured' | 'failed' | 'refunded';
}
